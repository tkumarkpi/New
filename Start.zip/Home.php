<html>
<?php 
session_start();
if(!empty($_SESSION["logged_in"])){
echo "<div style='text-align:right'>Welcome ". $_SESSION['user_name']."<br />"."</div>";
} 

else{
    
    
    echo '<script type="text/javascript">
           window.location = "lon.php?msg=Login First :( "
      </script>';
    
} 
include("db.php");
$result=mysqli_query($conn,"SELECT * FROM exams"); ?> 
<head>
	<title>
		Welcome
	</title>
<a  href = "lon.php" >logout</a>
</head> 
<table border = "1" width = "100%" align ="center">
 <center><h1>Choose Your Exam</h1></center>
<tr>
<th>S.No</th>
<th>Exam Name/Your Choice</th>
<th>Description</th>
</tr> 
   

<?php
 while($test = mysqli_fetch_array($result))
			{
				$id = $test['id'];
?>		<tr>		
		<td align = "center" ><?php echo $test['id'] ?></td>
        <td ><?php echo $test['ExamName'] ?> <input type="radio" name="Exam" value="html" > <a  href ='choice.php?id=<?php echo "$id" ;  ?>'><button >ok</button></a></td>
        <td ><?php echo $test['description'] ?></td>
        
        
     </tr>   <?php } ?>
  </table>
  </body>
</html>

