<html>
<head>
<title>
Regeration Page
</title>
<link href = "css/style.css" type = "text/css" rel = "stylesheet">
</head>
<body>
<section class ="container">
<div class ="login">
<h1>Register Here!</h1>
<form action = "registered.php" method = "post">
<p><input type = "text" name = "lname" placeholder = "Last Name"></p>
<p><input type = "text" name = "fname" placeholder = "First Name*"></p>
<p><input type = "text" name = "email" placeholder = "Email*"></p>
<p><input type = "text" name = "pnumber" placeholder = "Phone Number*"></p>
<p><input type = "text" name="addr"  placeholder ="Address*" ></p>
<p><input type = "text" name = "examId" placeholder = "Exam Id*"></p>
<p><input type = "text" name = "ename" placeholder = "Exam Name*"></p>
<p><input type = "text" name = "uname" placeholder = "Username*"></p>
<p><input type = "password" name = "pass" placeholder ="Password*" ></p>
<p><input type = "password" name = "cpass" placeholder = "Confirm Password*" ></p>
<p><center><input type ="submit" value = "Submit" ></center></form>
</div>
<div class="login-help">

<p>Already a member !    
    <a href = "lon.php" target ="_blank">
 Login
    </a></p>
</div>
</section>

</body>
</html>