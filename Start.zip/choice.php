<html>
<?php
$id =$_REQUEST['id'];

switch($id){
    case 1:
    echo "Your choice was HTML";
    break;
    case 2:
    echo "Your choice was CSS";
    break;
    case 3:
    echo "Your choice was PHP";
    break;
    case 4:
    echo "Your choice was JAVASCRIPT";
    break;
    default:
    
    }
    ?>

</html>