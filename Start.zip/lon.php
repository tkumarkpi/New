<!DOCTYPE html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]> <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->

<html>
<title>Login</title>
<body>
<?php
session_start();
session_destroy();
if(!empty($_GET['msg'])){
echo "<h1>".$_GET['msg']."</h1>";
}
if(isset($_POST['commit']))
{session_start();
if(!empty($_POST["uname"])&&!empty($_POST["pass"])){
    
$username = "root";
$servername = "localhost";
$password = "";
$database = "assessment_exam";
// Create connection
$conn = mysqli_connect($servername, $username, $password);

// Check connection
    if (!$conn) {
        die("Connection failed: ".mysqli_connect_error());
    }
    


$db_selected = mysqli_select_db($conn,"assessment_exam");

    if (!$db_selected){
        die("<br />Database not found");
    }
    //echo "<br />Database found";
    
            
        $get_username= $_POST['uname'];
        
        $get_password= sha1($_POST['pass']);
        $sql="SELECT * FROM users WHERE Username= '$get_username' AND Password = '$get_password' ";

            if($result=mysqli_query($conn,$sql)){

                if(mysqli_num_rows($result)==1){
                   echo "<br />Login successfull";
                    $_SESSION["user_name"] = $_POST["uname"];
                    $_SESSION["logged_in"] = 1;
                     
                  header("Location: Home.php");
                
                }else{
                   echo "<br />Invalid Username or Password";
                }               
            }   else{
                 echo "Error: " . $query . "<br>" . mysqli_error($conn);;
                }               
        
 
} 
else{
    echo "Please Enter Username and Password";
}} ?>


<head>
 
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Login Form</title>
  <link rel="stylesheet" href="css/style.css">
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>
<body>
  <section class="container">
    <div class="login">
      <h1>Login to Web App</h1>
      <form method="post" >
        <p><input type="text" value="" placeholder="Username or Email" name = "uname"></p>
        <p><input type="password" value="" placeholder="Password" name = "pass"></p>
        <p class="remember_me">
          <label>
            <input type="checkbox" name="remember_me" id="remember_me">
            Remember me on this computer
          </label>
        </p>
        <p class="submit"><input type="submit" name="commit" value="Login"></p>
      </form>
    </div>

    <div class="login-help">
      <p>Not a member yet? <a href="registration.php">Click here !</a></p>
    </div>
  </section>

  <!--<section class="about">
    <p class="about-links">
      <a href="http://www.cssflow.com/snippets/login-form" target="_parent">View Article</a>
      <a href="http://www.cssflow.com/snippets/login-form.zip" target="_parent">Download</a>
    </p>
    <p class="about-author">
      &copy; 2012&ndash;2013 <a href="http://thibaut.me" target="_blank">Thibaut Courouble</a> -
      <a href="http://www.cssflow.com/mit-license" target="_blank">MIT License</a><br>
      Original PSD by <a href="http://www.premiumpixels.com/freebies/clean-simple-login-form-psd/" target="_blank">Orman Clark</a>
  </section>-->
</body>
</html>
