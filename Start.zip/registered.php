
<?php
if(!empty($_POST["lname"])&&!empty($_POST['fname'])&&!empty($_POST['email'])&&!empty($_POST['pnumber'])&&!empty($_POST['addr'])&&!empty($_POST['examId'])&&!empty($_POST['ename'])&&!empty($_POST['uname'])&&!empty($_POST['pass'])&&
!empty($_POST['cpass']))
{
  class rege{
    
            var $username; 
            var $servername; 
            var $password;
            var $database ;
            public $dbc;
            public $dbc1;
            
            public function connect($set_host, $set_username, $set_password){
            $this->servername = $set_host;
            $this->username = $set_username;
            $this->password = $set_password;
      
            $this->dbc = mysqli_connect($this->servername, $this->username, $this->password) or die('Error connecting to DB');        
               
            }
            
            public function db_select($set_database){
            $this->database = $set_database;
            $this->dbc1 = mysqli_select_db($this->dbc,$this->database);
            }            
                    
            public function query($sql){
            if (mysqli_query($this->dbc,$sql)){
                echo "<br /><br /><b>Your Data has been submitted successfully</b>";
                echo '<script type="text/javascript">
                      window.location = "lon.php"</script>';
            }   
            else {
                echo "Error: " . mysqli_error($this->dbc) . "<br />DATA NOT SUBMITTED" ;
            }
            
            
            
            }
            
            public function close(){
            return mysqli_close($this->dbc);
            
            }
            
}       
        $last_name = $_POST['lname'];
        $first_name = $_POST['fname'];
        $email = $_POST['email'];
        $phone_number = $_POST['pnumber'];
        $address = $_POST['addr'];
        $exam_id = $_POST['examId'];
        $exam_name = $_POST['ename'];
        $username = $_POST['uname'];
        $password = sha1($_POST['pass']);
        $confirm_pass = sha1($_POST['cpass']);
        $connection = new rege();
        $connection->connect('localhost', 'root', '');
        $connection->db_select('assessment_exam');
        $myquery = "insert into  users(LastName,FirstName,Email,Phone_Number,Address,Exam_Id,Exam_Name,Username,Password,Confirm_password) 
                      values('$last_name','$first_name','$email','$phone_number','$address','$exam_id','$exam_name','$username','$password','$confirm_pass')";
             
        $connection->query($myquery);
        $connection->close();
        
        
    }
       
    else{
        echo "<b>Data Not Submitted</b><br />";
        $fields = array("name","uname","email","pass","cpass");
foreach($fields as $field_agent){
    if(empty($_POST[$field_agent])){
    echo " <b>$field_agent is missing</b><br />"; 
}}
    }
?>

