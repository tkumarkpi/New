<?php  
	$conn = mysqli_connect('localhost', 'root', '');
	 if (!$conn)
    {
	 die('Could not connect: ' . mysql_error());
	}
	$db_selected = mysqli_select_db($conn,"assessment_exam");
?>

