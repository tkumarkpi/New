<?php
			include("db.php");
			
				
			$result=mysqli_query($conn,"SELECT * FROM users");
?>
<table border = "1" width = "100%" align ="center">
<h1>Information</h1>
<tr>
<th>ID </th> 
<th>First Name </th>
<th>Last Name </th>
<th>Email </th>
<th>Phone Number</th>
<th>Address</th>
<th>Exam Id </th>
<th>Exam Name</th>
<th>Username</th>
<th>Password</th>
<th>Confirm Password</th>
<th>Update/Delete</th>
</tr>			
<?php			
            while($test = mysqli_fetch_array($result))
			{
				$id = $test['id'];
                 //echo $id;
?>		<tr>		
		<td align = "center"><?php echo $test['id'] ?></td>
        <td align = "center"><?php echo $test['LastName'] ?></td>
        <td align = "center"><?php echo $test['FirstName'] ?></td>
        <td align  = "center"><?php echo $test['Email'] ?></td>
        <td align = "center"><?php echo $test['Phone_Number'] ?></td>
        <td align = "center"><?php echo $test['Address'] ?></td>
        <td align = "center"><?php echo $test['Exam_Id'] ?></td>
        <td align = "center"><?php echo $test['Exam_Name'] ?></td>
        <td align  = "center"><?php echo $test['Username'] ?></td>
        <td align  = "center"><?php echo $test['Password'] ?></td>
        <td align  = "center"><?php echo $test['Confirm_password'] ?></td>
        <td> <a  href ='view.php?id=<?php echo "$id" ;  ?>'><button >Update</button></a>
         <a  href ='del.php?id=<?php echo "$id" ;  ?>'><center><button>Delete</button></center></a></td>
        </tr>
<?php			}
			mysqli_close($conn);
			?>
            
            <tr>
