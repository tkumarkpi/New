<?php
require("db.php");
$id =$_REQUEST['id'];

$result = mysqli_query($conn,"SELECT * FROM users WHERE id  = '$id' ");
$test = mysqli_fetch_array($result);
if (!$result) 
		{
		die("Error: Data not found..");
		}
                $Last_Name=$test['LastName'] ;
				$First_Name=$test['FirstName'] ;
                $Email= $test['Email'] ;					
				$Phone_number=$test['Phone_Number'] ;
                $Address = $test['Address'] ;
                $Exam_id= $test['Exam_Id'] ;
                $Exam_name= $test['Exam_Name'] ;
                $Username=$test['Username'] ;
				$Password=$test['Password'] ;
                $Confirm_password=$test['Confirm_password'] ;

if(isset($_POST['save']))
{	
	$Last_save = $_POST['lname'];
	$First_save = $_POST['fname'];
    $Email_save = $_POST['email'];
	$Phone_save = $_POST['pnumber'];
    $Address_save = $_POST['addr'];
    $ExamId_save = $_POST['exam_id'];
    $ExamName_save = $_POST['exam_name'];
    $Username_save = $_POST['Uname'];
    $Password_save = $_POST['Pass'];
	$C_password_save = $_POST['Cpass'];

	mysqli_query($conn,"UPDATE users SET LastName ='$Last_save',FirstName ='$First_save' , Email ='$Email_save',Phone_Number = '$Phone_save',Address = '$Address_save' ,
		Exam_Id = '$ExamId_save' , Exam_Name='$ExamName_save', Username ='$Username_save',Password ='$Password_save' WHERE id = '$id'")
				or die(mysqli_error($conn)); 
	echo "Saved!";
	
	header("Location: index.php");			
}
mysqli_close($conn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<form method="post">
<table>
	<tr>
		<td>Last Name:</td>
		<td><input type="text" name="lname" value="<?php echo $Last_Name ?>"/></td>
	</tr>
	<tr>
		<td>First Name:</td>
		<td><input type="text" name="fname" value="<?php echo $First_Name ?>"/></td>
	</tr>
    <tr>
		<td>Email:</td>
		<td><input type="text" name="email" value="<?php echo $Email ?>"/></td>
	</tr>
	
    <tr>
		<td>Phone Number:</td>
		<td><input type="text" name="pnumber" value="<?php echo $Phone_number ?>"/></td>
	</tr>
    <tr>
		<td>Address:</td>
		<td><input type="text" name="addr" value="<?php echo $Address ?>"/></td>
	</tr>
    <tr>
		<td>Exam Id:</td>
		<td><input type="text" name="exam_id" value="<?php echo $Exam_id ?>"/></td>
	</tr>
    <tr>
		<td>Exam Name:</td>
		<td><input type="text" name="exam_name" value="<?php echo $Exam_name ?>"/></td>
	</tr>
    <tr>
		<td>Username</td>
		<td><input type="text" name="Uname" value="<?php echo $Username ?>"/></td>
	</tr>
	<tr>
		<td>Password</td>
		<td><input type="text" name="Pass" value="<?php echo $Password  ?>"/></td>
	</tr>
	<tr>
		<td>Confirm Password</td>
		<td><input type="text" name="Cpass" value="<?php echo $Confirm_password  ?>"/></td>
	</tr>
	
    <tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="save" value="save" /></td>
	</tr>
</table>

</body>
</html>
